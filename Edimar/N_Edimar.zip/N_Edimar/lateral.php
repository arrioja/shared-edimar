<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
<title>Untitled Document</title>
</head>

<body>
	<table width="100%"  border="0" cellspacing="0" cellpadding="0">
    <tr><td valign="top"><img src="Imagenes/Menu_lateral_Izq.jpg" width="8" height="439"></td>
    <td valign="top"><table width="95%"  border="0" cellspacing="0" cellpadding="0">
    <tr><td><img src="Imagenes/Menu_lateral_I.jpg" width="118" height="27"></td></tr>
    <tr><td bgcolor="#3385B5">');
    <table width="104"  border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#3385B5" bgcolor="#FFFFFF">
    <tr><td align="center" height="21"><a href="#" onMouseOut="MM_swapImgRestore();MM_startTimeout();" onMouseOver="MM_swapImage(
    'acerkD','','Imagenes/acekD_II"+id+".jpg',1);MM_showMenu(window.mm_menu_0715190740_0,104,0,null,'acerkD')
    "><img src="Imagenes/acekD_I'+id+'.jpg" name="acerkD" width="104" height="21" border="0"></a></td>
    </tr><tr><td><a href="investigadores.php?'+UR+'Id='+id+"&Usr="+usr+'" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage(
    'Invest','','Imagenes/Invest_II"+id+".jpg',1)
    "><img src="Imagenes/Invest_I'+id+'.jpg" name="Invest" width="104" height="21" border="0"></a></td></tr>
    <tr><td><a href="#" onMouseOut="MM_swapImgRestore();MM_startTimeout();" onMouseOver="MM_swapImage(;
    'Dpto','','Imagenes/Dpto_II"+id+".jpg',1);MM_showMenu(window.mm_menu_0715191822_0,104,0,null,'Dpto')
    "><img src="Imagenes/Dpto_I'+id+'.jpg" name="Dpto" width="104" height="21" border="0"></a></td></tr>
    <tr><td><a href="#" onMouseOut="MM_swapImgRestore();MM_startTimeout();" onMouseOver="MM_swapImage(
    'invst','','Imagenes/Invst_II"+id+".jpg',1);MM_showMenu(window.mm_menu_0715192553_0,104,0,null,'invst')
    "><img src="Imagenes/Invst_I'+id+'.jpg" name="invst" width="104" height="21" border="0"></a></td></tr>
    <tr><td><a href="#" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage(
    'Educ','','Imagenes/Educ_II"+id+".jpg',1)
    "><img src="Imagenes/Educ_I'+id+'.jpg" name="Educ" width="104" height="21" border="0"></a></td></tr>
    <tr><td><a href="#" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage(
    'ext','','Imagenes/ext_II"+id+".jpg',1)
    "><img src="Imagenes/ext_I'+id+'.jpg" name="ext" width="104" height="21" border="0"></a></td></tr>
    <tr><td><a href="#" onMouseOut="MM_swapImgRestore();MM_startTimeout();" onMouseOver="MM_swapImage(');
    'Image22','','Imagenes/public_II"+id+".jpg',1);MM_showMenu(window.mm_menu_0715193247_0,104,0,null,'Image22')
    "><img src="Imagenes/public_I'+id+'.jpg" name="Image22" width="104" height="21" border="0"></a></td></tr>
    <tr><td><a href="#" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage(
    'Image23','','Imagenes/datos_II"+id+".jpg',1)
    "><img src="Imagenes/datos_I'+id+'.jpg" name="Image23" width="104" height="21" border="0"></a></td></tr>
    <tr><td><a href="#" onMouseOut="MM_swapImgRestore();MM_startTimeout();" onMouseOver="MM_swapImage(
    'noti','','Imagenes/not_II"+id+".jpg',1);MM_showMenu(window.mm_menu_0715193427_0,104,0,null,'noti')
    "><img src="Imagenes/not_I'+id+'.jpg" name="noti" width="104" height="21" border="0"></a></td></tr>
   <tr><td><a href="#" onMouseOut="MM_swapImgRestore();MM_startTimeout();" onMouseOver="MM_swapImage(
    'Image25','','Imagenes/empl_II"+id+".jpg',1);MM_showMenu(window.mm_menu_0715193533_0,104,0,null,'Image25')
    "><img src="Imagenes/empl_I'+id+'.jpg" name="Image25" width="104" height="21" border="0"></a></td></tr>
    <tr><td><a href="#" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage(
    'contc','','Imagenes/contac_II"+id+".jpg',1)
    "><img src="Imagenes/contac_I'+id+'.jpg" name="contc" width="104" height="21" border="0"></a></td></tr>
    <tr><td><a href="#" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage(
    'correo','','Imagenes/correo_II"+id+".jpg',1)
    "><img src="Imagenes/correo_I'+id+'.jpg" name="correo" width="104" height="21" border="0"></a></td></tr></table>
    </td></tr><tr><td width="118" height="40" align="center" valign="top" background="Imagenes/Menu_lateral_I_Inf.jpg">
    <a href="links.php?'+UR+'Id='+id+"&Usr="+usr+'" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage(
    'Links','','Imagenes/Link_II"+id+".jpg',1)
    "><img src="Imagenes/Link_I'+id+'.jpg" alt="Links" name="Links" width="104" height="21" border="0"></a></td></tr>
    </table><br><table width="100%"  border="0" cellspacing="0" cellpadding="0">
    <tr><td><img src="Imagenes/Servicios.jpg" width="118" height="34"></td></tr>
    <tr><td align="center" bgcolor="#85AD95">
    <table width="104"  border="1" cellpadding="0" cellspacing="0" bordercolor="#85AD95" bgcolor="#FFFFFF">
    <tr><td><a href="#" onMouseOut="MM_swapImgRestore();MM_startTimeout()" onMouseOver="MM_swapImage(
   'labt','','Imagenes/lab_II"+id+".jpg',1);MM_showMenu(window.mm_menu_0715202127_0,104,0,null,'labt')
    "><img src="Imagenes/lab_I'+id+'.jpg" name="labt" width="104" height="21" border="0"></a></td></tr>
    <tr><td><a href="#" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage(
   'const','','Imagenes/Consult_II"+id+".jpg',1)
    "><img src="Imagenes/Consult_I'+id+'.jpg" name="const" width="104" height="21" border="0"></a></td></tr>
    <tr><td><a href="#" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage(
    'sist','','Imagenes/Sist_II.jpg',1)
    "><img src="Imagenes/Sist_I.jpg" name="sist" width="104" height="33" border="0"></a></td></tr>
    </table></td></tr><tr>
    <td width="118" height="40" align="center" valign="top" background="Imagenes/Serv_inf.jpg">
    d<a href="#" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage(
    'buque','','Imagenes/Buq_II.jpg',1)
    "><img src="Imagenes/Buq_I.jpg" name="buque" width="104" height="33" border="0"></a></td></tr>
    </table><br><table width="100%"  border="0" cellspacing="0" cellpadding="0">
    <tr><td><img src="Imagenes/Collec.jpg" width="118" height="33"></td></tr>
    <tr><td height="40" align="center" bgcolor="#E96072">
    <a href="#" onMouseOut="MM_swapImgRestore();MM_startTimeout()" onMouseOver="MM_swapImage(;
    'museo','','Imagenes/museo_II.jpg',1);MM_showMenu(window.mm_menu_0715202233_0,104,0,null,'museo')
    "><img src="Imagenes/museo_I.jpg" name="museo" width="104" height="33" border="0"></a></td></tr>
   <tr><td height="30" bgcolor="#E96072"><img src="Imagenes/sesion.jpg" width="118" height="20"></td></tr> 
    <tr><td bgcolor="#E96072"><table width="100%"  border="0" cellspacing="0" cellpadding="0">
    <form name="form2" method="post" action=""><tr><td><table width="100%"  border="0" cellspacing="0" cellpadding="0">
    <tr><td width="53%" align="left" class="Letra_Sesion">&nbsp;Nombre:</td><td width="47%">');
    <input name="nick" type="text" size="4"></td></tr><tr><td align="left" class="Letra_Sesion">&nbsp;Clave:</td>
    <td><input name="pass" type="password" size="4"></td></tr></table></td></tr><tr>
   <td width="118" height="31" align="right" ><input type="submit" name="Submit2" value="Entrar">
    &nbsp;&nbsp;</td></tr></form></table></td></tr>
	
	<tr><td width="118" height="10" align="right" bgcolor="#E96072"><img src="Imagenes/Admin.jpg" name="Ad" width="116" height="27" border="0" ></td></tr>
	 <tr><td  bgcolor="#E96072" align="center"><table width="104"  border="1" cellpadding="0" cellspacing="0" bordercolor="#E96072" bgcolor="#FFFFFF">
	 <tr><td align="center" bgcolor="#E96072"><a href="Instusr.php?'+UR+'Id='+id+"&Usr="+usr+'" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage(
     'reg','','Imagenes/reg_II.jpg',1)
     "><img src="Imagenes/reg.jpg" name="reg" width="104" height="33" border="0"></a></td></tr>
	 <tr><td align="center" bgcolor="#E96072"><a href="permisos.php?'+UR+'Id='+id+"&Usr="+usr+'" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage(
    'AdPer','','Imagenes/AdPer_II.jpg',1)");
     "><img src="Imagenes/AdPer.jpg" name="AdPer" width="104" height="33" border="0"></a></td></tr>
	 </table></td></tr>
	
	
	
		<tr><td width="118" height="10" align="right" bgcolor="#E96072"><img src="Imagenes/Admin.jpg" name="Ad" width="116" height="27" border="0" ></td></tr>');
	<tr><td align="center" bgcolor="#E96072"><a href="datosP.php?'+UR+'Id='+id+"&Op=M&Usr="+usr+'" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage(
    'Contra','','Imagenes/CambPass_II.jpg',1)
    "><img src="Imagenes/CambPass.jpg" name="Contra" width="104" height="33" border="0"></a></td></tr>
	
	<tr><td width="118" height="31" align="right" background="Imagenes/Collec_Inf.jpg" >&nbsp;</td></tr>
	</table><p>&nbsp;</p><p>&nbsp;</p></td>');
   <td valign="top"><img src="Imagenes/Menu_lateral_I_Der.jpg" width="19" height="194"></td></tr></table> 
</body>
</html>
